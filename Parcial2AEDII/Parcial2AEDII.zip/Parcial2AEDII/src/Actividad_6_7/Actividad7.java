package Actividad_6_7;

import Interfaces.Arco;
import Interfaces.Grafo;
import Interfaces.Vertice;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Actividad7 {

    /**
     * Produce: devuelve un iterador sobre los predecesores del vértice v en el
     * grafo g. Se dice que w es predecesor del vértice v si existe un arco que
     * tenga por origen w y por destino v, es decir, el arco (w,v) pertenece al
     * conjunto de arcos del grafo.
     */
    public static <E, T> Iterator<Vertice<E>> predecesores(Grafo<E, T> g, Vertice<E> v) {
        List<Vertice<E>> pred = new ArrayList<>();
        Iterator<Vertice<E>> itV = g.vertices();
        while (itV.hasNext()) {
            Vertice<E> origen = itV.next();
            Iterator<Vertice<E>> itD = g.adyacentes(origen);
            while (itD.hasNext()) {
                if (itD.next().equals(v)) {
                    pred.add(origen);
                    break;
                }
            }
        }
        return pred.iterator();
    }

    /**
     * Un vértice se dice sumidero si su grado de entrada es n-1 y su grado de
     * salida es 0. |V|=n, es decir, n es el número de vértices del grafo.
     *
     * @param <E>
     * @param <T>
     * @param g
     * @param v
     * @return
     */
    public static <E, T> boolean esSumidero(Grafo<E, T> g, Vertice<E> v) {
        Iterator<Vertice<E>> it = g.vertices();
        if (!it.hasNext()) { //Es vacio
            return false;
        }
        if (g.adyacentes(v).hasNext()) {//si v tiene adyacentes, grado de salida != 0
            return false;
        }

        while (it.hasNext()) {
            Vertice<E> actual = it.next();
            Iterator<Vertice<E>> it2 = g.adyacentes(actual);
            while (it2.hasNext() && !actual.equals(v)) {
                actual = it2.next();
                //Mientras existan adyacentes a actual, comprueba si son el vertice
                //Si actual es v, el bucle no se ejecuta
            }
            if (!actual.equals(v)) {
                //No se ha encontrado v, es decir, ni estamos en v ni adyacentes a v despues de recorrer los adyacentes
                return false;
            }
        }
        return true;
    }

    /**
     * Escribe un método que devuelva cierto si un grafo es regular. Un grafo es
     * regular si todos sus vértices tienen el mismo número de vértices
     * adyacentes.
     *
     * @param <E>
     * @param <T>
     * @param g
     * @return
     */
    public static <E, T> boolean esRegular(Grafo<E, T> g) {
        Iterator<Vertice<E>> it = g.vertices();
        int num = 0xCAFE;
        if (it.hasNext()) {
            num = numAdyacentes(g, it.next());
        }
        while (it.hasNext()) {
            if (num != numAdyacentes(g, it.next())) {
                return false;
            }
        }

        return true;
    }

    private static <E, T> int numAdyacentes(Grafo<E, T> g, Vertice<E> v) {
        Iterator<Vertice<E>> it = g.adyacentes(v);
        int num = 0;
        while (it.hasNext()) {
            num++;
            it.next();
        }
        return num;
    }

    /**
     * Escribe un método que demuestre el teorema del apretón de manos. Dicho
     * teorema dice que la suma de los grados de un grafo es igual al doble del
     * número de aristas. También dice que en un grafo siempre hay un número par
     * de vértices de grado impar
     *
     * @param <E>
     * @param <T>
     * @param g
     * @return
     */
    public static <E, T> boolean lemaApretonManos(Grafo<E, T> g) {
        int numGradoImpar = 0;
        int sumaGrados = 0;
        int numAristas = 0;
        int gradoActual;
        Iterator<Arco<E, T>> itArco = g.arcos();
        List<Arco<E, T>> arcos = new ArrayList<>();
        while (itArco.hasNext()) {
            //Cuenta las aristas y las guarda para usarlas
            arcos.add(itArco.next());
            numAristas++;
        }

        Iterator<Vertice<E>> it = g.vertices();
        //Recorre cada vertice, calculando su grado
        while (it.hasNext()) {
            Vertice<E> v = it.next();
            gradoActual = 0;
            for (Arco<E, T> arco : arcos) {
                if (arco.getOrigen().equals(v)) {
                    gradoActual++; //Aumenta el grado de salida
                }
                if (arco.getDestino().equals(v)) {
                    gradoActual++; //Aumenta el grado de llegada
                }
            }
            numGradoImpar += gradoActual % 2;
            sumaGrados += gradoActual;
        }

        return numGradoImpar % 2 == 0 && sumaGrados == 2 * numAristas;
    }

    /**
     * Escribe un método que dado un grafo dirigido y dos vértices devuelva
     * cierto si existe un camino simple de un vértice a otro.
     *
     * @param <E>
     * @param <T>
     * @param g
     * @param v1
     * @param v2
     * @return
     */
    public static <E, T> boolean hayCaminoEntreDos(Grafo<E, T> g, Vertice<E> v1, Vertice<E> v2) {
        if (!g.estaVertice(v2) || !g.estaVertice(v1)) {
            return false;
        }
        return hayCamino(g, v1, v2, new ArrayList());
    }

    private static <E, T> boolean hayCamino(Grafo<E, T> g, Vertice<E> v1, Vertice<E> v2, List<Vertice<E>> visitados) {
        visitados.add(v1);
        Iterator<Vertice<E>> it = g.adyacentes(v1);
        Vertice<E> destino;
        while (it.hasNext()) {
            destino = it.next();
            if (destino == v2) {
                return true;
            }
            if (!visitados.contains(destino) && hayCamino(g, destino, v2, visitados)) {
                //Si el destno no ha sido visitado, se comprueba si tiene camino a v2
                //Si un vertice adyacente al actual tiene camino, hay camino
                return true;
            }
        }
        return false;
    }

    /**
     * Dado un grafo y una secuencia de vértices, escribe un método que
     * determine si dicha secuencia de vértices es un ciclo del grafo. Dado un
     * grafo G, un ciclo en G es una secuencia de nodos de G
     * [v(1),v(2),v(3),...,v(n)] tal que: 
     * i) v(1) = v(n), 
     * ii) (v(1),v(2)),(v(2),v(3)), (v(3),v(4)), ..., (v(n-1),v(n)) son aristas de G, 
     * ii) salvo v(1) = v(n), todos los v(i) son distintos entre sí.
     *
     * @param <E>
     * @param <T>
     * @param g
     * @param camino
     * @return
     */
    public static <E, T> boolean esCiclo(Grafo<E, T> g, List<Vertice<E>> camino) {
        if (!g.vertices().hasNext()) {
            return false; //grafo vacio
        }
        if (camino.isEmpty() || !camino.get(0).equals(camino.get(camino.size() - 1))) {
            //si esta vacio o si el primero y el ultimo de camino son distintos, no es un ciclo
            return false;
        }
        return esCiclo(g, camino, new ArrayList());
    }

    private static <E, T> boolean esCiclo(Grafo<E, T> g, List<Vertice<E>> camino, List<Vertice<E>> visitados) {

        Vertice<E> actual = camino.remove(0);
        if (visitados.contains(actual)) {
            //si actual ya visitado, tiene que ser el ultimo
            return camino.isEmpty();
        }
        visitados.add(actual);
        if (!g.estaVertice(actual)) {
            return false;
            //no esta en el grafo el vertice actual
        }

        Iterator<Vertice<E>> it = g.adyacentes(actual);
        Vertice<E> destino;
        while (it.hasNext()) {
            destino = it.next();
            if (destino.equals(camino.get(0))) { //destino es el siguiente del camino
                return esCiclo(g, camino, visitados);
            }
        }

        return false; //No quedan adyacentes 
    }

}
